f_length = open('length_num')
f_cluster = open('length_cluster','w')

for line in f_length:
    line = line.strip('\n')
    length = line.split('\t')[0]
    print(length)
    f_cluster.write(length)
    f_cluster.write(':')
    f_prophage = open('prophage_length.tsv')
    for prophage in f_prophage:
        prophage = prophage.strip('\n')
        if prophage.split('\t')[1] == length:
            f_cluster.write(prophage.split('\t')[0])
            f_cluster.write('\t')
    f_cluster.write('\n')
    f_prophage.close()

f_length.close()
f_cluster.close()

