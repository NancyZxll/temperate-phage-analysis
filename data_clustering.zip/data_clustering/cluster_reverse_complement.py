def check(line):
    line_replace = line.replace('A','0').replace('C','0').replace('G','0').replace('T','0').replace('N','0').replace('a','0').replace('c','0').replace('g','0').replace('t','0').replace('n','0')
    return line_replace.isnumeric()

def reverse_complement(sequence):
    comp_dict = {
        "A":"T",
        "T":"A",
        "G":"C",
        "C":"G",
        "a":"t",
        "t":"a",
        "g":"c",
        "c":"g",
        "n":"n",
        "N":"N",
    }
    sequence_list = list(sequence)
    sequence_list = [comp_dict[base] for base in sequence_list]
    string = ''.join(sequence_list)
    return string[::-1]

f_cluster = open('length_cluster')
count = 0
for cluster in f_cluster:
    cluster = cluster.strip('\n').rstrip('\t')
    file_cluster = ''.join(cluster.split(':',1)[1:])
    file_list = file_cluster.split('\t')

    seq_list = []

    for prophage in file_list:
        prophage_f = open('data_choose/'+prophage)
        fa_seq = ''
        repeat1 = ''
        repeat2 = ''
        for line in prophage_f.readlines():
            line = line.rstrip()
            if ('repeat1' in line and 'repeat2' in line):
                repeat1 = line.split('repeat1: ')[1].split('repeat2: ')[0].strip(' ')
                repeat2 = line.split('repeat2: ')[1].strip(' ')
            elif check(line):
                fa_seq = fa_seq + line
        fa_seq = fa_seq + repeat2

        if fa_seq in seq_list:
            record_f = open('data_cluster_reverse_complement'+str(seq_list.index(fa_seq)+1+count),'a+')
            record_f.write(prophage)
            record_f.write('\n')
            record_f.close()

        elif reverse_complement(fa_seq) in seq_list:
            record_f = open('data_cluster_reverse_complement'+str(seq_list.index(reverse_complement(fa_seq))+1+count),'a+')
            record_f.write(prophage)
            record_f.write('\n')
            record_f.close()

        else:
            record_f = open('data_cluster_reverse_complement'+str(len(seq_list)+1+count),'w')
            record_f.write(prophage)
            record_f.write('\n')
            record_f.close()
            seq_list.append(fa_seq)

    count = count + len(seq_list)
    print(count)
