import os

def check(line):
    line_replace = line.replace('A','0').replace('C','0').replace('G','0').replace('T','0').replace('N','0').replace('a','0').replace('c','0').replace('g','0').replace('t','0').replace('n','0')
    return line_replace.isnumeric()

path_in = 'data_choose'
files= os.listdir(path_in)

f_out = open('prophage_length.tsv','w')

for file in files:
    print(file)
    prophage_f = open(path_in + '/' + file)
    fa_seq = ''
    repeat1 = ''
    repeat2 = ''
    for line in prophage_f.readlines():
        line = line.rstrip()
        if ('repeat1' in line and 'repeat2' in line):
            repeat1 = line.split('repeat1: ')[1].split('repeat2: ')[0].strip(' ')
            repeat2 = line.split('repeat2: ')[1].strip(' ')
        elif check(line):
            fa_seq = fa_seq + line
    fa_seq = fa_seq + repeat2
    f_out.write(file)
    f_out.write('\t')
    f_out.write(str(len(fa_seq)))
    f_out.write('\n')
    

    


