#!/usr/bin/python
# -*- coding: utf-8 -*-
# usage: python /mounst/user/zhangxll/Scripts/extract_from_assembly_summary.v2.py -s 947S.list -r GCF_000006925.2_301_chr.fna -n NC_004337.2 -c 30


import argparse
import os
import re
import sys
# import collections

__authors__ = 'wyr, Xianglilan Zhang'


SCRIPT_PATH = '/mount/user/zhangxll/Softwares/CuiLab_Pipeline/mnt/Script/ZhouZheMin/core_ope/'
PARALLE_SCRIPT = '/mount/user/zhangxll/Softwares/CuiLab_Pipeline/mnt/Script/multi-process.pl'
REPEAT_TO_GFF_SCRIPT = '/mount/user/zhangxll/Softwares/CuiLab_Pipeline/mnt/self.software/BGAP/repeat/repeat_to_gff.pl'
REPEAT_FILTER_SCRIPT = '/mount/user/zhangxll/Softwares/CuiLab_Pipeline/mnt/Script/bin/Repeat/Repeat_filter.pl'
ROMOVE_POLYMORPHIC_SNP_SCRIPT = '/mount/user/zhangxll/Softwares/CuiLab_Pipeline/mnt/self.software/SNP_Pipeline/snp_stat-wyr.pl'
NJ2PHYML_FORMAT_SCRIPT = '/mount/user/zhangxll/Softwares/CuiLab_Pipeline/mnt/Script/bin/FormatTrans/nj2phyml_format_v2.pl'
FA_STAT_SCRIPT = '/mount/user/zhangxll/Softwares/CuiLab_Pipeline/mnt/Script/fa_stat.pl'
# if len(sys.argv) < 2:
#   print 'Usage: python {} <assembly_summary.txt>'.format(sys.argv[0])
#   sys.exit(-1)

str_info = {}


def excluded_string_from_refseq(assembly_summary_file):
    with open(assembly_summary_file, 'r') as f:
        for line in f.readlines():
            if line.startswith('#'):
                continue
            line = line.replace('\n', '')
            array = line.split('\t')
            if array[20] == '':
                array[8] = re.sub('^strain=', '', array[8])
                str_info[array[0]] = '\t'.join([array[0], array[8], array[14]])
            else:
                continue
    return str_info


def string_info(str_info, fa_path_file):
    str_info_file = open('str_info_file.txt', 'w')
    with open(fa_path_file, 'r') as f:
        for line in f.readlines():
            if line.startswith('#'):
                continue
            if re.search('final.fa', line):
                continue
            line = line.replace('\n', '')
            fa_name = (line.split('/')[-1]).split('_')
            genbank_accession = '_'.join([fa_name[0], fa_name[1]])
            if genbank_accession in str_info.keys():
                str_info_file.write('{}\t{}\n'.format(str_info[genbank_accession], line))
    str_info_file.close()


def mummer_align_to_ref(sorted_fa_path_file, ref_file=None, cpu_num=4):
    os.system('mkdir -p 01.mummer_align_to_ref')
    os.system('mkdir -p tmp')

    try:
        cmd = open('01.mummer_align_to_ref.sh', 'w')        
        with open(sorted_fa_path_file, 'r') as f:
            lines = f.readlines()
            if ref_file is None:
                # total_isolates_num = len(lines)
                ref_file = lines[0].strip().split('\t')[-1]
                if re.search('.gz$', ref_file):
                    os.system('gunzip {} -c >tmp/ref.fa'.format(ref_file))
                else:
                    os.system('cp {} tmp/ref.fa'.format(ref_file))
                for line in lines[1:]:
                    if line.startswith('#'):
                        continue
                    array = line.strip().split('\t')
                    # align_name = re.sub('(.tar)?.gz | .tgz', '', line.split('/')[-1])
                    # if re.search('.tar.gz$', array[-1]) or re.search('.tgz$', arrya[-1]):
                    #   cmd.write('tar zxf {} -C tmp|perl {}nucmer_filter.pl {} {} >01.mummer_align_to_ref/{}.align |rm tmp/{}'.format(array[-1], SCRIPT_PATH, ref_file, array[-1], array[0], array[0]))
                    if re.search('.gz$', array[-1]):
                        os.system('gunzip {} -c >tmp/{}.fa'.format(array[-1], array[0]))
                        cmd.write('perl {}nucmer_filter.pl tmp/ref.fa tmp/{}.fa 01.mummer_align_to_ref/{}.align\n'.format(SCRIPT_PATH, array[0], array[0]))
                        # cmd.write('gunzip {} -c >tmp/{}.fa && perl {}nucmer_filter.pl tmp/ref.fa tmp/{}.fa 01.mummer_align_to_ref/{}.align && rm tmp/{}.fa\n'.format(array[-1], array[0], SCRIPT_PATH, array[0], array[0], array[0]))
                    else:
                        cmd.write('perl {}nucmer_filter.pl tmp/ref.fa {} 01.mummer_align_to_ref/{}.align\n'.format(SCRIPT_PATH, array[-1], array[0]))
            else:
                # total_isolates_num = len(lines) + 1
                for line in lines:
                    if line.startswith('#'):
                        continue
                    array = line.strip().split('\t')
                    if re.search('.gz$', ref_file):
                        os.system('gunzip {} -c >tmp/ref.fa'.format(ref_file))
                    else:
                        os.system('cp {} tmp/ref.fa'.format(ref_file))                    
                    # align_name = re.sub('(.tar)?.gz | .tgz', '', line.split('/')[-1])
                    # if re.search('.tar.gz$') or re.search('.tgz$'):
                    #   cmd.write('tar zxf {} -C tmp|perl {}nucmer_filter.pl {} {} >01.mummer_align_to_ref/{}.align |rm tmp/{}'.format(line, SCRIPT_PATH, ref_file, line, align_name, align_name))
                    if re.search('.gz$', array[-1]):
                        os.system('gunzip {} -c >tmp/{}.fa'.format(array[-1], array[0]))
                        cmd.write('perl {}nucmer_filter.pl tmp/ref.fa tmp/{}.fa 01.mummer_align_to_ref/{}.align\n'.format(SCRIPT_PATH, array[0], array[0]))
                        # cmd.write('gunzip {} -c >tmp/{}.fa && perl {}nucmer_filter.pl tmp/ref.fa tmp/{}.fa 01.mummer_align_to_ref/{}.align && rm tmp/{}.fa\n'.format(array[-1], array[0], SCRIPT_PATH, array[0], array[0], array[0]))
                    else:
                        cmd.write('perl {}nucmer_filter.pl tmp/ref.fa {} 01.mummer_align_to_ref/{}.align\n'.format(SCRIPT_PATH, array[-1], array[0]))
        cmd.close()
        # paralle
        os.system('perl {} -cpu {} -verbose 01.mummer_align_to_ref.sh 2>>mummer.log'.format(PARALLE_SCRIPT, cpu_num))
        # rm gunzip file in tmp dir
        os.system('ls tmp/* |grep -v "ref.fa" |xargs rm -rf')
        ref_file = 'tmp/ref.fa'
        # return ref_file, total_isolates_num
        return ref_file
    except IOError:
        print '{} not exists!'.format(sorted_fa_path_file)
        sys.exit(1)
    except Exception as e:
        raise e
    finally:
        cmd.close()


def merge_mummer_align(ref_file, threshold=0.8):
    try:
        # exlude strains with the length ratio of align result to the ref less than threshold   
        os.system('mkdir -p 01.mummer_align_to_ref/tmp')
        total_isolates_num = 0

        align_str = os.popen('ls 01.mummer_align_to_ref/*.align').read().split('\n')

        for item in align_str:
            if item == '':
                continue
            print ("now processing: {}".format(item))
            print("threshold is",threshold) 
            fa_stat = os.popen('perl {} {}'.format(FA_STAT_SCRIPT, item)).read().split('\n')[0]
            temp = fa_stat.split('\t')
            print "------fa_stat.split is {}".format(temp)
            if float(int(temp[2])) / int(temp[1]) < float(threshold):
                print float(int(temp[2])) / int(temp[1])
                os.system('mv {} 01.mummer_align_to_ref/tmp/'.format(item))
            else:
                print float(int(temp[2])) / int(temp[1])
                total_isolates_num += 1      
        # merge left align results  
        os.system('cat {} 01.mummer_align_to_ref/*.align >02.merge_mummer_align.fa'.format(ref_file))
        return total_isolates_num + 1
    except IOError:
        print '{} not exists!'.format(ref_file)
        sys.exit(1)
    except Exception as e:
        raise e


def call_core_genome(total_isolates_num, relaxed_genome_num_percent=0, ref_name=None):
    # os.system('mkdir -p 03.call_core_genome')
    try:
        if ref_name is None:
            ref_name = os.popen("head -1 tmp/ref.fa|awk '{print $1}' |sed 's/>//;'").readlines()[0]
            ref_name = ref_name.replace('\n', '')
            os.system('perl {}core_genome_build.pl 02.merge_mummer_align.fa {} {} >03.core_genome.fa'.format(SCRIPT_PATH, ref_name, int(total_isolates_num * relaxed_genome_num_percent)))
        else:        
            os.system('perl {}core_genome_build.pl 02.merge_mummer_align.fa {} {} >03.core_genome.fa'.format(SCRIPT_PATH, ref_name, int(total_isolates_num * relaxed_genome_num_percent)))
    except Exception as e:
        raise e


def call_ref_dup(ref_file):
    try:
        # mkdir and cd
        # os.system('mkdir -p 04.call_ref_dup')
        # formatdb and blastn
        os.system('formatdb -i {} -p F && blastall -p blastn -d {} -i {} -m 8 -F F -e 1e-5 -o ref.blastn.out'.format(ref_file, ref_file, ref_file))
        # trf and trans format
        os.system('/mount/user/zhangxll/Softwares/trf409.linux64 {} 2 7 7 80 10 50 2000 -d -h'.format(ref_file))
        os.system('perl {} *.dat'.format(REPEAT_TO_GFF_SCRIPT))

        # call dup region
        os.system('{} -ref {} -out dup_region -trf *.gff -blast ref.blastn.out'.format(REPEAT_FILTER_SCRIPT, ref_file))
        # exit dir
        # os.system('cd ..')
    except Exception as e:
        raise e


def remove_dup_in_coregenome():
    try:
        os.system('perl {}core_remove_region.pl 03.core_genome.fa dup_region >05.rmdup_core_genome.fa'.format(SCRIPT_PATH))
    except Exception as e:
        raise e


def call_snp():
    try:
        os.system('perl {}core_map2snp.pl 05.rmdup_core_genome.fa >06.SNP.matrix'.format(SCRIPT_PATH))
    except Exception as e:
        raise e


def rm_polymorphic_SNP(total_isolates_num):
    try:
        os.system('cut -f 1-{} 06.SNP.matrix >06.SNP.matrix.tmp && perl {} 06.SNP.matrix.tmp dup_region 07.clean.SNP.matrix && rm 06.SNP.matrix.tmp'.format(1 + total_isolates_num, ROMOVE_POLYMORPHIC_SNP_SCRIPT))
    except Exception as e:
        raise e


def snp2fas():
    try:
        os.system('perl {}core_snp2fas.pl 07.clean.SNP.matrix >08.clean.SNP.matrix.fa'.format(SCRIPT_PATH))
    except Exception as e:
        raise e


def build_nj_tree():
    try:
        os.system('/mount/user/zhangxll/Softwares/treebest-1.9.2/treebest nj -b 0 08.clean.SNP.matrix.fa >09.SNP.matrix.nj.tree.newic')
    except Exception as e:
        raise e


def nj2phyml_format():
    try:
        os.system('perl {} 09.SNP.matrix.nj.tree.newic 0 09.SNP.matrix.nj.tree'.format(NJ2PHYML_FORMAT_SCRIPT))
    except Exception as e:
        raise e


def parameters():
    parser = argparse.ArgumentParser()
    # subparser = parser.add_subparsers()

    # parser_genbank = subparser.add_parser('genbank', description='Reorganize GenBank assembly_summary.txt file and strain path list file')
    # parser_genbank.add_argument("-a", "--assembly_summary", help="assembly_summary.txt, download from GenBank")
    # parser_genbank.add_argument("-l", "--fapath_list", help="GenBank strain path list")
    # parser_normal = subparser.add_parser('normal', description='Strain name-path list (tab-separated)')
    # parser_normal.add_argument("-s", "--strain_name_path", help="GenBank strain name and path file")
    parser.add_argument("-a", "--assembly_summary", help="assembly_summary.txt, download from GenBank")
    parser.add_argument("-l", "--fapath_list", help="GenBank strain path list")
    parser.add_argument("-s", "--strain_name_path", help="GenBank strain name and path file")
    parser.add_argument("-r", "--reference_file", default=None, help="reference fasta file path, default: the first line")
    parser.add_argument("-n", "--reference_name", default=None, help="reference name")
    parser.add_argument("-p", "--percent", default=0, type=float, help="relaxed genome num percent")
    parser.add_argument("-c", "--cpunum", default=8, type=int, help="paralle step1: mummer align to ref")
    parser.add_argument("-t", "--threshold", default=0.8, type=float, help="the ratio of mummer align result effective length to total ref length")
    args = parser.parse_args()
    help = parser.format_help()

    return args, help


def main():
    args, help = parameters()

    if args.reference_file:
        reference_file = args.reference_file
    else:
        reference_file = None

    if args.reference_name:
        reference_name = args.reference_name
    else:
        reference_name = None

    if args.percent:
        percent = args.percent
    else:
        percent = 0

    if args.assembly_summary and args.fapath_list:
        print "\n----- Step0: Exclude strains not in refseq -----\n"
        str_info = excluded_string_from_refseq(args.assembly_summary)
        string_info(str_info, args.fapath_list)
        print "\n----- Step1: MUMmer alignment to a reference -----\n"
        ref_file = mummer_align_to_ref('str_info_file.txt', ref_file=args.reference_file, cpu_num=args.cpunum)
    elif args.strain_name_path:
        print "\n----- Step1: MUMmer alignment to a reference -----\n"
        ref_file = mummer_align_to_ref(args.strain_name_path, ref_file=args.reference_file, cpu_num=args.cpunum)
        print (ref_file)
    else:
        print help
        sys.exit(1)

    print "\n----- Step2: Merge different MUMmer alignment to a multiple fasta file -----\n"
    print "\n-------- args.threshod is {}".format(args.threshold)
    total_isolates_num = merge_mummer_align(ref_file, args.threshold)
    print "\n----- Step3: Call (relaxed) core genome -----\n"
    call_core_genome(total_isolates_num, relaxed_genome_num_percent=args.percent, ref_name=args.reference_name)
    print "\n----- Step4: Call reference genome repeat region -----\n"
    call_ref_dup(ref_file)
    print "\n----- Step5: Remove some regions in the core genome -----\n"
    remove_dup_in_coregenome()
    print "\n----- Step6: Call SNPs from core genome -----\n"
    call_snp()
    print "\n----- Step7: Remove polymorphic SNPs -----\n"
    rm_polymorphic_SNP(total_isolates_num)
    print "\n----- Step8: Generate a SNP-only fasta file -----\n"
    snp2fas()
    print "\n----- Step9: Build NJ Tree and transformat-----\n"
    build_nj_tree()
    nj2phyml_format()


if __name__ == '__main__':
    main()
