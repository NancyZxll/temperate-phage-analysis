#! /usr/bin/perl -w
use strict;

die "usage:perl $0 <nj.tree> <bootstrap> <phyml.format>\n" unless(@ARGV==3);

open NJ,"$ARGV[0]" or die "$!\n";
open OU,">$ARGV[2]" or die "$!\n";

my $boot = $ARGV[1];
$boot = $boot/100;

while(<NJ>){
    chomp;
    if(/NHX:B/){
        s/\:([^:\]]+)\[\&\&NHX:B=(\d+)\]/int($2*$boot+0.5).":".$1/e;
        s/\)\[&&NHX:B=\d+\]/\)/;
        print OU "$_\n";
    }else{
        s/\[&&NHX\]//;
        print OU "$_\n";
    }
}

# yangxianwei

