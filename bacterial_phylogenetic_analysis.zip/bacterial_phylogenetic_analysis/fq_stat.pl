#! /usr/bin/perl -w
use strict;

die "Usage: perl $0 <reads.fq> <.....>\n" unless(@ARGV>=1);

my (@temp,$total,$eff,$num,$reads);
print "\t\t\tReadNum\t\tTotalLen\tEffectiveLen\n";
foreach $reads(@ARGV){
    $total = 0;
    $eff = 0;
    $num = 0;
    print "$reads\t";

    if($reads=~/\.gz$/){
        open IN,"gzip -dc $reads | " or die "$!\n";
    }else{
        open IN,"$reads" or die "$!\n";
    }

    while(<IN>){
        chomp;
        chomp(my $line = <IN>);
        $total += length($line);
        $line =~ s/N//ig;
        $eff +=length($line);
        $num++;
        <IN>; <IN>;
    }

    print "$num\t$total\t$eff\n";

    close IN;
}
