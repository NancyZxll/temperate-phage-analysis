#! /usr/bin/perl

use strict;
use Getopt::Long;

my ($trf,$rmker,$ref,$out,$help,$blast);
GetOptions(
	"trf:s"=>\$trf,
	"rmker:s"=>\$rmker,
	"blast:s"=>\$blast,
	"ref:s"=>\$ref,
	"out:s"=>\$out,
	"help"=>\$help
);

unless($trf or $rmker or $blast) {
	&usage();
	exit;
}

unless($ref) {
	&usage();
	exit;
}

my $char = 'R';

my %refseq = ();
&get_seq($ref,\%refseq);
my @process = ();

push @process,$trf if($trf);
push @process,$rmker if($rmker);
open OUT,">$out" or die "$out $!\n" ;

foreach my $file(@process) {
	open FILE,$file or die "$file $!\n";
	while(<FILE>) {
		next if(/^#/);
		chomp;
		my @t = split;
		my $seq = $refseq{$t[0]};
		my $head = substr($seq,0,$t[3]-1);
		my $tail = substr($seq,$t[4],length($seq)-$t[4]);
		my $mid = $char x ($t[4]-$t[3]+1);
		$refseq{$t[0]} = $head.$mid.$tail;
	}
	close(FILE);
}

if($blast) {
	open FILE,$blast or die "$blast $!\n";
	while(<FILE>) {
		chomp;
		my @t = split;
		die "Wrong blast result file\n" unless(scalar(@t)==12);
		next if($t[0] eq $t[1] && $t[6] == $t[8] && $t[7] == $t[9]);
		if($t[3]>=50) {
			next if($t[2] < 95);
		} elsif($t[3]>=25) {
			next if($t[2] != 100);
		} else {
			next;
		}
		my $seq = $refseq{$t[0]};
		my ($b,$e) = ($t[6],$t[7]);
		my $head = substr($seq,0,$b-1);
		my $tail = substr($seq,$e,length($seq)-$e);
		my $mid = $char x ($e-$b+1);
		$refseq{$t[0]} = $head.$mid.$tail;
		$seq = $refseq{$t[1]};
		($b,$e) = ($t[8]>$t[9]) ? ($t[9],$t[8]) : ($t[8],$t[9]);
		$head = substr($seq,0,$b-1);
		$tail = substr($seq,$e,length($seq)-$e);
		$mid = $char x ($e-$b+1);
		$refseq{$t[1]} = $head.$mid.$tail;
	}
	close(FILE);
}

foreach my $name (keys(%refseq)) {
	my @out = &find_position($refseq{$name});
	for(my $i=0;$i<scalar(@out);$i+=2) {
		print OUT $name,"\t",$out[$i],"\t",$out[$i+1],"\n";
	}
}
close(OUT);

sub find_position {
	my $seq = shift;
	my @res = ();
	my @t = split(//,$seq);
	my $flag = 0;
	for(my $i = 0;$i<scalar(@t);++$i) {
		if($t[$i] eq $char && $flag == 0) {
			push @res,$i+1;
			$flag = 1;
		}
		if($t[$i] ne $char && $flag == 1) {
			push @res,$i;
			$flag = 0;
		}
		if($t[$i] eq $char && $i == length($seq)-1 && $flag == 1) {
			push @res,$i;
			$flag = 0;
		}
	}
	return @res;
}

# Sub program : get the sequence from file into the hash:

sub get_seq {
	my $file = shift;
	my $hash = shift;
	open TMP,$file or die "$file $!\n";
	my ($seq,$name) = ('','');
	while(<TMP>) {
		chomp;
		if(/^>(\S+)/) {
			$hash->{$name} = $seq if($seq ne '');
			$name = $1;
			$seq = '';
		} else {
			$seq .= $_;
		}
	}
	$hash->{$name} = $seq if($seq ne '');
}

# Sub Program : usage :
sub usage {
	print STDERR <<USAGE;
	
	****####^^^^@@@@
	
	Description : 

	filter repeat position from the repeat masker, trf, and blast self.

	Author foky.chen, chenye2\@genomics.cn

	version 1.0

	Usage:  $0 -ref [sequence] -out [position of repeat] <options>
	
	-ref	  <S>: the sequence.
	
	-out      <S>: the output of repeat position.

	<options> : 

	-trf      <S>: get repeat position from trf.

	-rmker    <S>: get repeat position from repeat masker.

	-blast    <S>: get repeat position from blast result.
	
	-help     <S>: output this help message.

USAGE
}
