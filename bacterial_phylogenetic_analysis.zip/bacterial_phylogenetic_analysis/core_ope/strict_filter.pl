#! /usr/bin/perl

$delta = shift;

open (DELTA, "<$delta") or die;
$line = <DELTA>;print $line;
$line = <DELTA>;print $line;

while (<DELTA>) {
	if($_ =~ /^>(\S+) (\S+) (\d+) (\d+)/) {
		chomp $_;
		$ref = $1; $qry = $2; $length{"R:$ref"} = $3; $length{"Q:$qry"} = $4;
		@align_file = `show-aligns -q $delta \"$ref\" \"$qry\"`;
		for(local $i=0; $i< @align_file; ++$i) {
			$line = $align_file[$i];
			if($line =~ /^-- BEGIN alignment \[ (..) (\d+) - (\d+) \| (..) (\d+) - (\d+) \]/) {
				$ref_seq = ""; $qry_seq = ""; $ref_d = $1; $ref_s = $2; $ref_e = $3; $qry_d = $4; $qry_s = $5; $qry_e = $6;
				for(;$i < @align_file; ++$i) {
					$i+=3;
					chomp $align_file[$i];
					if($align_file[$i] =~ /^$/) {
						last;
					}
					$ref_line = $align_file[$i]; $ref_line =~ /(\d+)\s+(\S+)/;
					$ref_seq .= $2;
					$qry_line = $align_file[$i+1]; $qry_line =~ /(\d+)\s+(\S+)/;
					$qry_seq .= $2;
				}
				
				@{$alignment[@alignment]} = ($ref, $ref_d, $ref_s, $ref_e, $qry, $qry_d, $qry_s, $qry_e, $ref_seq, $qry_seq);
			}
		}
	}
}
close DELTA;

@alignment = sort {if($$a[0] eq $$b[0]) {$$a[2] <=> $$b[2]} else {$$a[0] cmp $$b[0]}} @alignment;

for(local $i=1; $i<@alignment; ++$i) {
	if($alignment[$i][0] eq $alignment[$i-1][0] && $alignment[$i][2] <= $alignment[$i-1][3]) {
		local %cut_para; $cut_para{$alignment[$i][2]-1} = 1;
		
		local $ref_site = $alignment[$i-1][3] + $alignment[$i-1][1]; local $qry_site = $alignment[$i-1][7]+$alignment[$i-1][5];
		for(local $m=length($alignment[$i-1][8])-1; $m >=0; $m --) {
			local $ref_base = substr($alignment[$i-1][8], $m, 1);
			local $qry_base = substr($alignment[$i-1][9], $m, 1);
			if($ref_base ne ".") {
				$ref_site -= $alignment[$i-1][1];
			}
			if($qry_base ne ".") {
				$qry_site -= $alignment[$i-1][5];
			}
			if($ref_site == $alignment[$i][2]-1) {
				last;
			}
			if($ref_base ne $qry_base) {
				$cut_para{$ref_site-1} = 1;
			}
		}
		
		local $ref_site2 = $alignment[$i][2] - $alignment[$i][1]; local $qry_site2 = $alignment[$i][6]-$alignment[$i][5];
		for(local $n=0; $n <length($alignment[$i][8]); ++$n) {
			local $ref_base = substr($alignment[$i][8], $n, 1);
			local $qry_base = substr($alignment[$i][9], $n, 1);
			if($ref_base ne ".") {
				$ref_site2 += $alignment[$i][1];
			}
			if($qry_base ne ".") {
				$qry_site2 += $alignment[$i][5];
			}
			if($ref_site2 == $alignment[$i-1][3]+1) {
				last;
			}
			if($ref_base ne $qry_base) {
				$cut_para{$ref_site2} = 1;
			}
		}		
		

		local @cut_matrix;
		foreach $cut (keys %cut_para) {
			local $mismatch = 0;
			local $ref_site = $alignment[$i-1][3] + $alignment[$i-1][1]; local $qry_site = $alignment[$i-1][7]+$alignment[$i-1][5];
			local $m; local $n;
			for($m=length($alignment[$i-1][8])-1; $m >=0; $m --) {
				local $ref_base = substr($alignment[$i-1][8], $m, 1);
				local $qry_base = substr($alignment[$i-1][9], $m, 1);
				if($ref_base ne ".") {
					$ref_site -= $alignment[$i-1][1];
				}
				if($qry_base ne ".") {
					$qry_site -= $alignment[$i-1][5];
				}
				if($ref_site == $cut) {
					last;
				}
				if($ref_base ne $qry_base) {
					$mismatch ++;
				}
			}
			
			local $ref_site2 = $alignment[$i][2] - $alignment[$i][1]; local $qry_site2 = $alignment[$i][6]-$alignment[$i][5];
			for($n=0; $n <length($alignment[$i][8]); ++$n) {
				local $ref_base = substr($alignment[$i][8], $n, 1);
				local $qry_base = substr($alignment[$i][9], $n, 1);
				if($ref_base ne ".") {
					$ref_site2 += $alignment[$i][1];
				}
				if($qry_base ne ".") {
					$qry_site2 += $alignment[$i][5];
				}
				if($ref_site2 == $cut+1) {
					last;
				}
				if($ref_base ne $qry_base) {
					$mismatch ++;
				}
			}
			@{$cut_matrix[@cut_matrix]} = ($cut, $mismatch, $m, $ref_site, $qry_site, $n, $ref_site2, $qry_site2);
		}
		@cut_matrix = sort {$$b[1] <=> $$a[1]} @cut_matrix;
		$alignment[$i-1][3] = $cut_matrix[0][3]; $alignment[$i-1][7] = $cut_matrix[0][4]; 
		$alignment[$i-1][8] = substr($alignment[$i-1][8], 0, $cut_matrix[0][2]+1); $alignment[$i-1][9] = substr($alignment[$i-1][9], 0, $cut_matrix[0][2]+1);
		$alignment[$i][2] = $cut_matrix[0][6]; $alignment[$i][6] = $cut_matrix[0][7]; 
		$alignment[$i][8] = substr($alignment[$i][8], $cut_matrix[0][5], length($alignment[$i][8])); $alignment[$i][9] = substr($alignment[$i][9], $cut_matrix[0][5], length($alignment[$i][9]));
		if(substr($alignment[$i][9], 0, 1) eq ".") {
			$alignment[$i][6] = $alignment[$i][6]+$alignment[$i][5];
		}
		if(substr($alignment[$i-1][9], -1, 1) eq ".") {
			$alignment[$i-1][7] = $alignment[$i-1][7]-$alignment[$i-1][5];
		}
	}
}

foreach $ali (@alignment) {
	if($$ali[5] == 1) {
		local $tmp = "$$ali[4] $$ali[5] $$ali[6] $$ali[7] $$ali[0] $$ali[1] $$ali[2] $$ali[3] $$ali[9] $$ali[8]";
		@$ali = split /\s/, $tmp;
	} else {
		local $tmp = "$$ali[4] +1 $$ali[7] $$ali[6] $$ali[0] -1 $$ali[3] $$ali[2] $$ali[9] $$ali[8]";
		@$ali = split /\s/, $tmp;
		$$ali[8] = reverse $$ali[8]; $$ali[8] =~ tr/ATCGatcg/TAGCtagc/;
		$$ali[9] = reverse $$ali[9]; $$ali[9] =~ tr/ATCGatcg/TAGCtagc/;
	}
}

@alignment = sort {if($$a[0] eq $$b[0]) {$$a[2] <=> $$b[2]} else {$$a[0] cmp $$b[0]}} @alignment;

for(local $i=1; $i<@alignment; ++$i) {
	if($alignment[$i][0] eq $alignment[$i-1][0] && $alignment[$i][2] <= $alignment[$i-1][3]) {
		local %cut_para; $cut_para{$alignment[$i][2]-1} = 1;
		
		local $ref_site = $alignment[$i-1][3] + $alignment[$i-1][1]; local $qry_site = $alignment[$i-1][7]+$alignment[$i-1][5];
		for(local $m=length($alignment[$i-1][8])-1; $m >=0; $m --) {
			local $ref_base = substr($alignment[$i-1][8], $m, 1);
			local $qry_base = substr($alignment[$i-1][9], $m, 1);
			if($ref_base ne ".") {
				$ref_site -= $alignment[$i-1][1];
			}
			if($qry_base ne ".") {
				$qry_site -= $alignment[$i-1][5];
			}
			if($ref_site == $alignment[$i][2]-1) {
				last;
			}
			if($ref_base ne $qry_base) {
				$cut_para{$ref_site-1} = 1;
			}
		}
		
		local $ref_site2 = $alignment[$i][2] - $alignment[$i][1]; local $qry_site2 = $alignment[$i][6]-$alignment[$i][5];
		for(local $n=0; $n <length($alignment[$i][8]); ++$n) {
			local $ref_base = substr($alignment[$i][8], $n, 1);
			local $qry_base = substr($alignment[$i][9], $n, 1);
			if($ref_base ne ".") {
				$ref_site2 += $alignment[$i][1];
			}
			if($qry_base ne ".") {
				$qry_site2 += $alignment[$i][5];
			}
			if($ref_site2 == $alignment[$i-1][3]+1) {
				last;
			}
			if($ref_base ne $qry_base) {
				$cut_para{$ref_site2} = 1;
			}
		}
	
		local @cut_matrix;
		foreach $cut (keys %cut_para) {
			local $mismatch = 0;
			local $ref_site = $alignment[$i-1][3] + $alignment[$i-1][1]; local $qry_site = $alignment[$i-1][7]+$alignment[$i-1][5];
			local $m; local $n;
			for($m=length($alignment[$i-1][8])-1; $m >=0; $m --) {
				local $ref_base = substr($alignment[$i-1][8], $m, 1);
				local $qry_base = substr($alignment[$i-1][9], $m, 1);
				if($ref_base ne ".") {
					$ref_site -= $alignment[$i-1][1];
				}
				if($qry_base ne ".") {
					$qry_site -= $alignment[$i-1][5];
				}
				if($ref_site == $cut) {
					last;
				}
				if($ref_base ne $qry_base) {
					$mismatch ++;
				}
			}
			
			local $ref_site2 = $alignment[$i][2] - $alignment[$i][1]; local $qry_site2 = $alignment[$i][6]-$alignment[$i][5];
			for($n=0; $n <length($alignment[$i][8]); ++$n) {
				local $ref_base = substr($alignment[$i][8], $n, 1);
				local $qry_base = substr($alignment[$i][9], $n, 1);
				if($ref_base ne ".") {
					$ref_site2 += $alignment[$i][1];
				}
				if($qry_base ne ".") {
					$qry_site2 += $alignment[$i][5];
				}
				if($ref_site2 == $cut+1) {
					last;
				}
				if($ref_base ne $qry_base) {
					$mismatch ++;
				}
			}
			@{$cut_matrix[@cut_matrix]} = ($cut, $mismatch, $m, $ref_site, $qry_site, $n, $ref_site2, $qry_site2);
		}
		@cut_matrix = sort {$$b[1] <=> $$a[1]} @cut_matrix;
		$alignment[$i-1][3] = $cut_matrix[0][3]; $alignment[$i-1][7] = $cut_matrix[0][4]; 
		$alignment[$i-1][8] = substr($alignment[$i-1][8], 0, $cut_matrix[0][2]+1); $alignment[$i-1][9] = substr($alignment[$i-1][9], 0, $cut_matrix[0][2]+1);
		$alignment[$i][2] = $cut_matrix[0][6]; $alignment[$i][6] = $cut_matrix[0][7]; 
		$alignment[$i][8] = substr($alignment[$i][8], $cut_matrix[0][5], length($alignment[$i][8])); $alignment[$i][9] = substr($alignment[$i][9], $cut_matrix[0][5], length($alignment[$i][9]));
		if(substr($alignment[$i][9], 0, 1) eq ".") {
			$alignment[$i][6] = $alignment[$i][6]+$alignment[$i][5];
		}
		if(substr($alignment[$i-1][9], -1, 1) eq ".") {
			$alignment[$i-1][7] = $alignment[$i-1][7]-$alignment[$i-1][5];
		}
	}
}

for(local $i=0; $i<@alignment; ++$i) {
	local $ali = $alignment[$i];
	if($$ali[5] == 1) {
		local $tmp = "$$ali[4] $$ali[5] $$ali[6] $$ali[7] $$ali[0] $$ali[1] $$ali[2] $$ali[3] $$ali[9] $$ali[8]";
		@$ali = split /\s/, $tmp;
	} else {
		local $tmp = "$$ali[4] +1 $$ali[7] $$ali[6] $$ali[0] -1 $$ali[3] $$ali[2] $$ali[9] $$ali[8]";
		@$ali = split /\s/, $tmp;
		$$ali[8] = reverse $$ali[8]; $$ali[8] =~ tr/ATCGatcg/TAGCtagc/;
		$$ali[9] = reverse $$ali[9]; $$ali[9] =~ tr/ATCGatcg/TAGCtagc/;
	}
	if($$ali[3]-$$ali[2]+1 < 40) {
		splice(@alignment, $i, 1); $i --;
	}
}

@alignment = sort {if($$a[4] eq $$b[4]) {$$a[0] cmp $$b[0]} else {$$a[4] cmp $$b[4]}} @alignment;
foreach $ali (@alignment) {
	if($$ali[0] ne $prev_0 || $$ali[4] ne $prev_4) {
		print ">$$ali[0] $$ali[4] ".$length{"R:$$ali[0]"}." ".$length{"Q:$$ali[4]"}."\n";
	}
	local $prev_indel = -1; local @indel; local $mismatch = 0;
	for(local $i=0; $i<length($$ali[8]); ++$i) {
		local $s_seq = substr($$ali[8], $i, 1);
		local $q_seq = substr($$ali[9], $i, 1);
		if($s_seq ne $q_seq) {
			$mismatch ++;
		}
		if($s_seq eq ".") {
			$indel[@indel] = -($i - $prev_indel);
			$prev_indel = $i;
		} elsif ($q_seq eq ".") {
			$indel[@indel] = $i - $prev_indel;
			$prev_indel = $i;
		}
	}
	print "$$ali[2] $$ali[3] $$ali[6] $$ali[7] $mismatch $mismatch 0\n";
	foreach (@indel) {
		print "$_\n";
	}
	print "0\n";

	$prev_0 = $$ali[0]; $prev_4 = $$ali[4];
}
