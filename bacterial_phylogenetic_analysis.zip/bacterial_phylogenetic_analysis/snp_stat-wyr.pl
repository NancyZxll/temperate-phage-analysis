#! /usr/bin/perl
use strict;
use warnings;

die "Usage: perl $0 [snp.matrix][snp_on_repeat][outfile]\n" unless (@ARGV == 3);
open IN,"$ARGV[0]" or die "$ARGV[0] Error!\n";
open RP,"$ARGV[1]" or die "$ARGV[1] Error!\n";
open OT,">$ARGV[2]" or die "$ARGV[2] Error\n";
my %hash;

my %repeat;
while(<IN>){
    chomp;
    next if(/^\s+/);
    my @a = split;
    $repeat{$a[0]}=1;
}

my %exists;
while(<RP>){
    chomp;
    my @a=split;
    foreach my $key (keys %repeat){
        my @key = split /\_/,$key;
        my $scaffold = $key;
        $scaffold =~ s/_\d+$//;
        next unless($scaffold eq /$a[0]/);
        if($key[-1]>=$a[1] and $key[-1]<=$a[2]){
            $exists{$key}=1;
        }
    }
}

seek IN,0,0;
while(<IN>){
    chomp;
    print OT "$_\n" if(/^\s+|#/);
    my ($a,$a0,$a2,$ag)=(0,0,0,0,);
    my $base = 0;
    my %base = ();
    next if(/^\s+|#/);
    my @a=split /\t/;
    next if(exists $exists{$a[0]});
    shift @a;
    for my $key ( 0 .. (@a-1)){
        $a[$key] = uc $a[$key];
        if($a[$key] =~ /2/){
            $a2++;
            $a++;
        }elsif($a[$key] =~ /0/){
            $a0++;
            $a++;
        }elsif($a[$key] =~ /\-/){
            $ag++;
            $a++;
        }elsif($a[$key] =~ /[ATCG]/){
            $base ++;
            $base{$a[$key]}++;
        }
    }

    $hash{"all"}{$a}++;
    $hash{"0"}{$a0}++;
    $hash{"2"}{$a2}++;
    $hash{"gap"}{$ag}++;
    my $te = scalar keys %base;
    next if($te != 2);
    my $t = scalar @a;
    print OT "$_\n" if($base == $t);
}

foreach my $key (sort keys %hash){
    print "$key:\n";
    foreach my $subkey (sort {$a <=>$b} keys %{$hash{$key}}){
        print "$subkey\t$hash{$key}{$subkey}\n";
    }
    print "\n";
}
