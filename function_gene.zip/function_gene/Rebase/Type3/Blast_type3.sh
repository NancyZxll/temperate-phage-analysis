blastn -query R_subunit -db /mnt/disk2_workspace/wangruohan/Phage_Beijing/paper_result/data_V2/Blast_new/BlastDB/allprophage_DB -outfmt ' 6 qaccver saccver pident qlen slen length mismatch gapopen qstart qend sstart send evalue bitscore' -evalue 1e-5 -num_threads 30 -out R_result

blastn -query M_subunit -db /mnt/disk2_workspace/wangruohan/Phage_Beijing/paper_result/data_V2/Blast_new/BlastDB/allprophage_DB -outfmt ' 6 qaccver saccver pident qlen slen length mismatch gapopen qstart qend sstart send evalue bitscore' -evalue 1e-5 -num_threads 30 -out M_result


