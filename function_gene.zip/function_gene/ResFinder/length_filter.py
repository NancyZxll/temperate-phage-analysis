f_in = open('ResFinder_result')
f_out = open('ResFinder_result_filter','w')

for line in f_in:
    gene_length = int(line.split('\t')[3])*1.0
    match_length = int(line.split('\t')[5])*1.0
    if match_length/gene_length > 0.9:
        f_out.write(line)

f_in.close()
f_out.close()
